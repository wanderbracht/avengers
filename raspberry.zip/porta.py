#!/usr/bin/python

import serial
import RPi.GPIO as GPIO
import os, time

GPIO.setmode(GPIO.BOARD)
port = serial.Serial("/dev/ttyS0", baudrate=9600, timeout=1)
while True:
	serialcmd = "A"
	port.write(str.encode(serialcmd))
	rcv = port.read(10)
	print(rcv)
