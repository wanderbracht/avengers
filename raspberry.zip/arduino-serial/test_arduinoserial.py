import arduinoserial
import pytest


# Not much to test :(
def test_arduinoserial():
    pass
