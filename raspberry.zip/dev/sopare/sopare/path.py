__plotdestination__ = "plot/"
__wavedestination__ = "tokens/"
__plugindestination__ = "plugins/"
